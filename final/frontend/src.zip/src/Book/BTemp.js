import './BTemp.css';
import React, { useEffect } from 'react';
import bg from './novel.jpg';
import { useNavigate } from 'react-router-dom';
import Rating from '@mui/material/Rating';
import { useState } from 'react';
import axios from 'axios';

function BTemp({data}) {
  

  const navigate=useNavigate();
const Bk=()=>{
     navigate('/Bpage/'+data.book_id);
}

  return(
    <div className='Book' onClick={Bk}>
      <div className='imgs'>
        <img src={data.image} id='im'></img>
      </div>
      <div className='cnt'>
        <h2>{data.title}</h2>
        <div id='a'>Author:{data.author}</div>
        <div id='a'>Price:{data.price}</div>
        <div id='a'>Genre:{data.genre}</div>
        <div id='a'>Age Rating:{data.ageRating}</div>
        <div id='a'><Rating/></div>
      </div>
    </div>
  );
}

export default BTemp;