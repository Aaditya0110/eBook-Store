import './BTemp.css';
import React from 'react';
import bg from './novel.jpg';
import './Asthetic.css';
import { useNavigate } from 'react-router-dom';

function Asthetic({data}) {
  const navigate=useNavigate();
  const Bk=()=>{
       navigate('/Bpage/'+data.book_id);
  }
  
  return(
    <div className='Book1' onClick={Bk}>
        <img src={data.image} className='imgs5'></img>
        <div className='cunt'>{data.title}</div>
    </div>
  );
}

export default Asthetic;