import React from "react";
import Rating from '@mui/material/Rating';
import './Review.css';
function Review({data}){
    return(
     <div className="rview">
         <h4>Name</h4>
         <div><Rating/></div>
         <div>Review:{data.review}</div>
     </div>
    )
}

export default Review;
