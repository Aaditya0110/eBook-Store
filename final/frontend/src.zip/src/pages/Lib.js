import React from 'react';
import './Lib.css';
import { Link } from 'react-router-dom';
import Nav from './Nav';
import Asthetic from '../Book/Asthetic'
import axios from 'axios';
import { useState,useEffect } from 'react';
function Lib() {
  const token=localStorage.getItem("jwtToken");
  const [books, setBooks] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:8181/books", {
      headers: {
        Authorization: "Bearer " + token
      }
    })
      .then((res) => {
        setBooks(res.data);
      })
      .catch(error => {
        console.log(error);
      });
  }, []);

  return(
    <div>
      <div className='naval'>
         <Nav/>
      </div>
      <div className='books2'>
      {books.map((b)=>{
          return(
            <Asthetic data={b}/>
          )
        })}
      </div>
    </div>
  );
}

export default Lib;