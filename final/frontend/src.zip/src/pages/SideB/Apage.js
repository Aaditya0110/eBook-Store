import React from 'react';
// import './Home.css';
// import Nav from './Nav';
// import Bar from './homeComponents/Bar';
import Nav from '../Nav';
import Sortf from './Sortf';
import './Gpage.css'
import BTemp from '../../Book/BTemp';
import axios from 'axios';
import { useState,useEffect } from 'react';
import { connect } from 'react-redux';

function Apage(){
  const token=localStorage.getItem("jwtToken");
  const [books, setBooks] = useState([]);
//   const params={{props.genre}};

 useEffect(() => {
    const url="http://localhost:8181/books";
    axios.get(url, {
      headers: {
        Authorization: "Bearer " + token
      }
    })
      .then((res) => {
        setBooks(res.data.map((b)=>{
            return(
              <BTemp data={b}/>
              )
            }));
      })
      .catch(error => {
        console.log(error);
      });
    }, []);
    const [selectedOption, setSelectedOption] = useState(''); // State to store the selected option
  useEffect(
    ()=>{
        async function func()
        {
            console.log('ji');
            try { 
                const fld="http://localhost:8181/books/order/"+selectedOption;
                const response = await axios.get(fld,{
                  headers: {
                    Authorization: "Bearer " + token
                  }
                });
                setBooks(response.data.map((b)=>{
                  return(
                    <BTemp data={b}/>
                    )
                  }));
              } catch (error) {
                console.error(error);
              }

        }
        func();
    },[selectedOption]
  )



  const handleDropdownChange = async (event) => {
    const selectedValue = event.target.value;
    setSelectedOption(selectedValue);
  };
  return(
    <div className='All'>
      <div className='naval'>
       <Nav/>
      </div>
      <div className='sr'>
        Sort:
        <select value={selectedOption} onChange={handleDropdownChange}>
       <option value='Author'>Default</option>
        {/* <option value='Author'>Price High-Low</option>
        <option value='Author'>Price Low-High</option>
        <option value='Author'>Rating High-Low</option>
        <option value='Author'>Rating Low-High</option>
        <option value='pages'>Pages High-Low</option> */}
        <option value='pages'>Pages Low-High</option>
        <option value='title'>Title</option>
       </select>
      </div>
      {/* <br/> */}
      <div className='GBooks'>
      {books}
      </div>
      {/* <>{props.genre}a</> */}
    </div>
  );
}

export default Apage;