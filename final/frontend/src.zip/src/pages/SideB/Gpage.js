import React from 'react';
// import './Home.css';
// import Nav from './Nav';
// import Bar from './homeComponents/Bar';
import Nav from '../Nav';
import Sortf from './Sortf';
import './Gpage.css'
import BTemp from '../../Book/BTemp';
import axios from 'axios';
import { useState,useEffect } from 'react';
import { connect } from 'react-redux';

function Gpage(props) {
  const token=localStorage.getItem("jwtToken");
  const [books, setBooks] = useState([]);
  // const params={{props.genre}};

  useEffect(() => {
    const url="http://localhost:8181/books/genre/"+props.genre;
    axios.get(url, {
      headers: {
        Authorization: "Bearer " + token
      }
    })
      .then((res) => {
        setBooks(res.data);
      })
      .catch(error => {
        console.log(error);
      });
  }, []);
  return(
    <div className='All'>
      <div className='naval'>
       <Nav/>
      </div>
      <div className='sr'>
      <Sortf/>
      </div>
      {/* <br/> */}
      <div className='GBooks'>
      {books.map((b)=>{
        return(
          <BTemp data={b}/>
          )
        })}
      </div>
      {/* <>{props.genre}a</> */}
    </div>
  );
}
const mapstateToprops=(state)=>{
  return{
    genre:state.genre
  }
}

export default connect(mapstateToprops,null)(Gpage);