import { LoginOutlined } from '@mui/icons-material';
import React from 'react';

function Login() {
  return(
    <div>
      
    </div>
  );
}

export default LoginOutlined;