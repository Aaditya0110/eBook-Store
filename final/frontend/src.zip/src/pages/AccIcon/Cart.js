import { LoginOutlined } from '@mui/icons-material';
import React from 'react';
import CTemp from '../../Book/CTemp';

function Orders() {
  return(
    <div>
      <CTemp/>
    </div>
  );
}

export default Orders;