import React from 'react';
// import './Home.css';
// import Nav from './Nav';
// import Bar from './homeComponents/Bar';
import Nav from '../Nav';
// import Sortf from './Sortf';
// import './Gpage.css'
import BTemp from '../../Book/BTemp';
import axios from 'axios';
import { useState,useEffect } from 'react';
import { connect } from 'react-redux';
import CTemp from '../../Book/CTemp'

function Top(){
  const token=localStorage.getItem("jwtToken");
  return(
    <div className='All'>
      <div className='naval'>
       <Nav/>
      </div>
      <div>
        <CTemp/> 
      </div>
    </div>
  );
}

export default Top;