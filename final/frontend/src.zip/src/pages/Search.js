import React from 'react';
import Nav from './Nav';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useEffect,useState } from 'react';
import './Search.css';
import BTemp from '../Book/BTemp';
import Asthetic from '../Book/Asthetic';

function Search() {
    const token=localStorage.getItem("jwtToken");
    const [searchTerm, setSearchTerm] = useState('');
    const [searchResults, setSearchResults] = useState([]);
  
    const handleSearch = async () => {
      try {
        const response = await axios.get('http://localhost:8181/api/books/search-by-title?title='+searchTerm, {
            headers: {
              Authorization: "Bearer " + token
            }
          });
        setSearchResults(response.data);
        console.log(response);
      } catch (error) {
        console.error(error);
      }
    };
    // useEffect(() => {
    //     const url="http://localhost:8181/api/books/search-by-title?title="+searchTerm;
    //     axios.get(url, {
    //       headers: {
    //         Authorization: "Bearer " + token
    //       }
    //     })
    //       .then((res) => {
    //         searchTerm(res.data.map((b)=>{
    //             return(
    //               <BTemp data={b}/>
    //               )
    //             }));
    //       })
    //       .catch(error => {
    //         console.log(error);
    //       });
    //     }, []);
  
    return (
      <div>
        <Nav/>
        <h2>Book Search</h2>
        <input
          type="text"
          value={searchTerm}
          className='sb'
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Enter book title"
        />
        <button onClick={handleSearch}>Search</button>
  
        {searchResults.length > 0 ? (
          <ul>
            {searchResults.map((book) => (
              <li key={book.bookId}>
                <BTemp data={book}/>
              </li>
            ))}
          </ul>
        ) : (
          <p></p>
        )}
      </div>
    );
  };
  

export default Search;